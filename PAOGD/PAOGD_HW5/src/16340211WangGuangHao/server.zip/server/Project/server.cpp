
#include <stdio.h>
#include <Winsock2.h> 
#include <Ws2tcpip.h>
#include <iostream>
#include <string>
#include <tchar.h>
#include <vector>
#include <algorithm>
#include <chrono>

using namespace std;
#pragma comment(lib, "ws2_32.lib")
#define BUFFER_SIZE 1024
class GameServer
{
public:
	GameServer() {

	}
	~GameServer() {

	}

	int InitSocket(int port) {
		WSADATA wsaData;
		char receBuf[BUFFER_SIZE];
		char Response[] = "";
		if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
			return -1;
		}

		serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
		if (serverSocket == INVALID_SOCKET) {
			printf("Failed socket() \n");
			return -1;
		}

		// ���÷�����
		char recvbuf = 1;
		setsockopt(serverSocket, SOL_SOCKET, SO_RCVBUF, &recvbuf, sizeof(int));
		u_long imode = 1;
		if (ioctlsocket(serverSocket, FIONBIO, &imode) != 0) {
			cout << "Init socket error 2" << endl;
			return -1;
		}
		// ���õ�ַ
		sockaddr_in serverAddr;
		serverAddr.sin_family = AF_INET;
		serverAddr.sin_addr.S_un.S_addr = INADDR_ANY; // �����ַ
		serverAddr.sin_port = htons(port);

		if (bind(serverSocket, (SOCKADDR*)& serverAddr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
			cout << "Bind socket error" << endl;
			return -1;
		}
		timeout.tv_sec = 0;
		timeout.tv_usec = 0;
		return 0;
	}

	void Listen() {
		while (true) {
		
			FD_ZERO(&rfd);
			FD_SET(serverSocket, &rfd);
			int SelectRcv = select(serverSocket + 1, &rfd, 0, 0, &timeout);
			if (SelectRcv < 0)
				cout << "Fali: " << GetLastError() << endl;
			else if (SelectRcv > 0) {
				// �յ����Կͻ��˵���Ϣ
				recvData();
			}
			Sleep(1);
			
		}
		closesocket(serverSocket);
		WSACleanup();
	}

private:
	SOCKET serverSocket;
	char recvBuf[1024];
	fd_set rfd;
	//vector<GameClient> clients;
	sockaddr_in clientAddr;
	int addrLen = sizeof(SOCKADDR);
	struct timeval timeout;
	bool running = false;
	char start[30] = "WELCOME ";
	char count = 'a';

	void recvData() {
		memset(recvBuf, 0, 1024);
		int recvLen = recvfrom(serverSocket, recvBuf, 1024, 0, (sockaddr*)& clientAddr, &addrLen);
		cout << "���ܵ���Ϣ" << endl;
		cout << recvBuf << endl;
		if (recvBuf[0] == '1') {
			start[8] = count;
			count++;
			start[9] = '\0';
			sendData(clientAddr, start, 10);
			
		}
		else if (recvBuf[0] == '2') {
			// �����ͻ�������
			handleInput();
		}
		
	}

	void sendData(sockaddr_in& clientAddr, char* data, int len) {
		sendto(serverSocket, data, len + 1, 0, (sockaddr*)& clientAddr, addrLen);
	}

	void handleInput() {
		
	}

	void updateGame() {
		
	}
};

int main() {
	GameServer server;

	if (server.InitSocket(4567) == 0) {
		cout << "Server is listening in 4567" << endl;
		server.Listen();
	}
}